from confluent_kafka import Producer
from confluent_kafka.serialization import StringSerializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from confluent_kafka.serializing_producer import SerializingProducer
subject = 'CTSCAN-ROOM-value'

# 1. Define the Avro Schema

avro_schema_str = """
{
  "namespace": "example.avro",
  "type": "record",
  "name": "CTSCAN_ROOM",
  "fields": [
    {"name": "HN", "type": "int"},
    {"name": "Name", "type": "string"},
    {"name": "Surname", "type": "string"},
    {"name": "Room_Number", "type": "int"},
    {"name": "CTSCAN_Type", "type": "int"},
    
  ]
}
"""

# 2. Setup Registry Client and Serializer
sr_conf = {'url': 'http://localhost:8081'}
schema_registry_client = SchemaRegistryClient(sr_conf)


v1_meta = schema_registry_client.get_version(subject, version=1)
v1_schema_str = v1_meta.schema.schema_str
avro_serializer = AvroSerializer(schema_registry_client, v1_schema_str)

# 3. Setup Producer
producer_conf = {
    'bootstrap.servers': 'localhost:8097,localhost:8098,localhost:8099',
    'key.serializer': StringSerializer(),
    'value.serializer': avro_serializer
    
}

avro_serializer = AvroSerializer(schema_registry_client, v1_schema_str)
p = SerializingProducer(producer_conf)
        
data = {"HN": 45678, "Name": "Sahaphum", "Surname": "Ketkaew", "Room_Number": 1 , "CTSCAN_Type": 1 , "Telephone" : "034-4567894"}

# Produce - SerializingProducer handles encoding automatically
p.produce(topic='CTSCAN-ROOM', key="c001", value=data)
p.flush()
print("Avro message produced.")