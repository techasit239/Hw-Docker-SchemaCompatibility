from confluent_kafka import Consumer
from confluent_kafka.serialization import StringDeserializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroDeserializer
from confluent_kafka.deserializing_consumer import DeserializingConsumer

# 1. Setup Registry Client
subject = 'CTSCAN-ROOM-value'
sr_conf = {'url': 'http://localhost:8081'}
schema_registry_client = SchemaRegistryClient(sr_conf)

#latest_meta = schema_registry_client.get_latest_version(subject)
latest_meta = schema_registry_client.get_version(subject, version=2)
v2_schema_str = latest_meta.schema.schema_str
print(f"Consumer pulled Latest Schema Version: {latest_meta.version}")
#print(f"Data :{v2_schema_str}")

# 2. Setup Avro Deserializer 
# the consumer pulls it from the Registry using the ID in the message.
avro_deserializer = AvroDeserializer(schema_registry_client)

# 3. Setup Consumer
consumer_conf = {
    'bootstrap.servers': 'localhost:8097,localhost:8098,localhost:8099',
    'key.deserializer': StringDeserializer(),
    'value.deserializer': avro_deserializer,
    'group.id': 'avro-group-8',
    'auto.offset.reset': 'latest'
}

consumer = DeserializingConsumer(consumer_conf)
consumer.subscribe(['CTSCAN-ROOM'])

print("Waiting for Avro messages...")

try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None: continue
        CT_INFORM = msg.value()
        print(f"Consumed Avro Movie: {CT_INFORM['HN']} ({CT_INFORM['Name']}) Telephone : {CT_INFORM['Telephone']}")

except KeyboardInterrupt:
    pass

finally:
    consumer.close()